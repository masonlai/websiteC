#!C:\Users\hihi\AppData\Local\Programs\Python\Python37-32\python.exe

import cgi, cgitb
from class_pymysql import *
cgitb.enable()
form = cgi.FieldStorage()
print('''
<html>
<body>
<form method=post action='delet.py'>
issue no: <input type='text' name='issueno'></input>
delet: <input type='text' name='delet'></input>
<input type='submit' name='' value='comfirm'></input>
</form>
''')

connect = cgi_to_db()
connect.Connect_to_db()
    
if form.getvalue('delet') != None:
    try:
        sqll = ("""DELETE FROM citizen '"""+"""'  where issueNo ='"""+form.getvalue('issueno')+"""'""")
        c = connect.Non_select(sqll)
    except:
        print('''gfdgsdg''')
    
print('''</body></html>''')
